package objetos;

public class Jogo {

}
